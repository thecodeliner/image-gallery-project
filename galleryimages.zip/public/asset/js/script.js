document.addEventListener('DOMContentLoaded', function() {
    const uploadArea = document.getElementById('uploadArea');
    const imageUploadInput = document.getElementById('imageUpload');
    const previewContainer = document.getElementById('imagePreviewContainer');
    const fileInfo = document.getElementById('fileInfo');
    const resetBtn = document.getElementById('resetBtn');
    const form = document.getElementById('galleryForm');

    // Handle file input click
    uploadArea.addEventListener('click', () => {
        imageUploadInput.click();
    });

    // Handle file selection
    imageUploadInput.addEventListener('change', handleFiles);

    // Drag and drop events
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, unhighlight, false);
    });

    function highlight(e) {
        e.preventDefault();
        e.stopPropagation();
        uploadArea.classList.add('active');
    }

    function unhighlight(e) {
        e.preventDefault();
        e.stopPropagation();
        uploadArea.classList.remove('active');
    }

    uploadArea.addEventListener('drop', function(e) {
        const dt = e.dataTransfer;
        imageUploadInput.files = dt.files;
        handleFiles({ target: imageUploadInput });
    });

    // Handle file processing
    function handleFiles(e) {
        const files = e.target.files;
        previewContainer.innerHTML = '';

        if (files.length > 0) {
            fileInfo.textContent = `${files.length} file(s) selected`;

            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                if (!file.type.startsWith('image/')) continue;

                const reader = new FileReader();
                reader.onload = function(e) {
                    createPreview(e.target.result, i);
                };
                reader.readAsDataURL(file);
            }
        } else {
            fileInfo.textContent = '';
        }
    }

    // Create image preview
    function createPreview(src, index) {
        const wrapper = document.createElement('div');
        wrapper.className = 'image-preview-wrapper';

        const img = document.createElement('img');
        img.src = src;
        img.className = 'image-preview';
        img.alt = 'Preview';

        const checkbox = document.createElement('input');
        checkbox.type = 'radio';
        checkbox.name = 'thumbnail_index';
        checkbox.value = index;
        checkbox.className = 'thumbnail-selector';
        checkbox.id = `thumb-${index}`;

        const label = document.createElement('label');
        label.htmlFor = `thumb-${index}`;
        label.className = 'thumbnail-label';

        wrapper.appendChild(checkbox);
        wrapper.appendChild(label);
        wrapper.appendChild(img);
        previewContainer.appendChild(wrapper);
    }

    // Reset form
    resetBtn.addEventListener('click', function() {
        previewContainer.innerHTML = '';
        fileInfo.textContent = '';
    });

    // Form validation
    form.addEventListener('submit', function(e) {
        const galleryName = document.getElementById('galleryName').value.trim();
        const files = imageUploadInput.files;

        if (!galleryName) {
            e.preventDefault();
            alert('Please enter a gallery name');
            return;
        }

        if (!files || files.length === 0) {
            e.preventDefault();
            alert('Please upload at least one image');
            return;
        }

        // Check if thumbnail is selected
        const thumbSelected = document.querySelector('input[name="thumbnail_index"]:checked');
        if (!thumbSelected) {
            e.preventDefault();
            alert('Please select a thumbnail image');
            return;
        }
    });
});
