<?php $__env->startSection('content'); ?>
<style>
    body {
        background-color: #f8f9fa;
        font-family: Arial, sans-serif;
    }

    .container {
        max-width: 800px;
        margin: 40px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }

    .section-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: #333;
        margin-bottom: 20px;
    }

    .form-label {
        font-weight: 500;
        color: #495057;
    }

    .form-control {
        border: 1px solid #ced4da;
        border-radius: 5px;
        padding: 10px;
        font-size: 1rem;
        transition: border-color 0.2s;
    }

    .form-control:focus {
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        outline: none;
    }

    .upload-area {
        border: 2px dashed #ced4da;
        border-radius: 10px;
        padding: 30px;
        text-align: center;
        background-color: #f8f9fa;
        transition: background-color 0.2s;
        cursor: pointer;
        position: relative;
    }

    .upload-area:hover {
        background-color: #e9ecef;
    }

    .upload-area i {
        color: #6c757d;
    }

    .upload-area p {
        margin: 0;
        color: #6c757d;
        font-size: 1rem;
    }

    .image-preview-container {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 20px;
        max-height: 300px;
        overflow-y: auto;
        padding: 10px;
    }

    .image-preview-wrapper {
        position: relative;
        width: 80px;
        height: 80px;
    }

    .image-preview {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 5px;
        border: 1px solid #dee2e6;
    }

    .image-checkbox {
        position: absolute;
        top: 5px;
        left: 5px;
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        border-radius: 5px;
        padding: 8px 16px;
        transition: background-color 0.2s;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    .btn-secondary {
        background-color: #6c757d;
        border-color: #6c757d;
        border-radius: 5px;
        padding: 8px 16px;
        transition: background-color 0.2s;
    }

    .btn-secondary:hover {
        background-color: #5a6268;
        border-color: #5a6268;
    }

    @media (max-width: 576px) {
        .container {
            margin: 20px;
            padding: 15px;
        }

        .section-title {
            font-size: 1.3rem;
        }

        .image-preview-wrapper {
            width: 60px;
            height: 60px;
        }
    }
</style>
</head>
<body>
<div class="container">
    <div class="section">
        <h2 class="section-title">Create Gallery and Upload Images</h2>
        <form id="galleryForm" method="post" action="<?php echo e(route('galleries.store')); ?>" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="mb-3">
                <label for="galleryName" class="form-label">Gallery Name</label>
                <input name="name" type="text" class="form-control" id="galleryName" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Upload Images (Check one for gallery thumbnail)</label>
                <div class="upload-area" id="uploadArea">
                    <i class="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                    <p>Drag & drop images here or click to browse</p>
                    <input type="file" name="images[]" id="imageUpload" multiple accept="image/*" style="opacity: 0; position: absolute; width: 100%; height: 100%; top: 0; left: 0; cursor: pointer;">
                </div>
                <div class="image-preview-container" id="imagePreviewContainer"></div>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Create and Upload</button>
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('galleryForm').reset(); document.getElementById('imagePreviewContainer').innerHTML = '';">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const uploadArea = document.getElementById('uploadArea');
    const imageUploadInput = document.getElementById('imageUpload');

    // Handle file input click
    uploadArea.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        imageUploadInput.click();
    });

    // Handle file selection for preview
    imageUploadInput.addEventListener('change', (event) => {
        const previewContainer = document.getElementById('imagePreviewContainer');
        previewContainer.innerHTML = ''; // Clear previous previews
        const files = event.target.files;

        for (let i = 0; i < files.length; i++) {
            const wrapper = document.createElement('div');
            wrapper.classList.add('image-preview-wrapper');

            const img = document.createElement('img');
            img.src = URL.createObjectURL(files[i]);
            img.classList.add('image-preview');

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.classList.add('image-checkbox');
            checkbox.name = 'thumbnail_index';
            checkbox.value = i;
            checkbox.addEventListener('change', (e) => {
                // Uncheck all other checkboxes
                document.querySelectorAll('.image-checkbox').forEach(cb => {
                    if (cb !== e.target) cb.checked = false;
                });
            });

            wrapper.appendChild(checkbox);
            wrapper.appendChild(img);
            previewContainer.appendChild(wrapper);
        }
    });

    // Handle drag and drop
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadArea.style.backgroundColor = '#e9ecef';
    });

    uploadArea.addEventListener('dragleave', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadArea.style.backgroundColor = '#f8f9fa';
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadArea.style.backgroundColor = '#f8f9fa';
        const files = e.dataTransfer.files;
        imageUploadInput.files = files;

        const previewContainer = document.getElementById('imagePreviewContainer');
        previewContainer.innerHTML = ''; // Clear previous previews

        for (let i = 0; i < files.length; i++) {
            const wrapper = document.createElement('div');
            wrapper.classList.add('image-preview-wrapper');

            const img = document.createElement('img');
            img.src = URL.createObjectURL(files[i]);
            img.classList.add('image-preview');

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.classList.add('image-checkbox');
            checkbox.name = 'thumbnail_index';
            checkbox.value = i;
            checkbox.addEventListener('change', (e) => {
                // Uncheck all other checkboxes
                document.querySelectorAll('.image-checkbox').forEach(cb => {
                    if (cb !== e.target) cb.checked = false;
                });
            });

            wrapper.appendChild(checkbox);
            wrapper.appendChild(img);
            previewContainer.appendChild(wrapper);
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/codeliner/laravel/galleryimages/resources/views/upload.blade.php ENDPATH**/ ?>