<?php $__env->startSection('content'); ?>
<h1 class="gallery-title">Photo Galleries</h1>

<div class="gallery-container">
    <button class="nav-arrow prev">
        <i class="fas fa-chevron-left"></i>
    </button>

    <div class="galleries-scroll" id="galleriesScroll">
        <!-- Gallery 1 -->
        <div class="gallery-card" onclick="openSwiperGallery('Nature Album', [
            'https://picsum.photos/1200/800?random=101',
            'https://picsum.photos/1200/800?random=102',
            'https://picsum.photos/1200/800?random=103',
            'https://picsum.photos/1200/800?random=104',
            'https://picsum.photos/1200/800?random=105'
        ])">
            <img src="https://picsum.photos/400/300?random=1" alt="Nature Album">
            <div class="gallery-overlay">
                <span class="name">Nature Album</span>
                <span class="items">5 photos</span>
            </div>
        </div>

        <!-- Gallery 2 -->
        <div class="gallery-card" onclick="openSwiperGallery('Cityscapes', [
            'https://picsum.photos/1200/800?random=201',
            'https://picsum.photos/1200/800?random=202',
            'https://picsum.photos/1200/800?random=203',
            'https://picsum.photos/1200/800?random=204'
        ])">
            <img src="https://picsum.photos/400/300?random=2" alt="Cityscapes">
            <div class="gallery-overlay">
                <span class="name">Cityscapes</span>
                <span class="items">4 photos</span>
            </div>
        </div>

        <!-- Gallery 3 -->
        <div class="gallery-card" onclick="openSwiperGallery('Portraits', [
            'https://picsum.photos/1200/800?random=301',
            'https://picsum.photos/1200/800?random=302',
            'https://picsum.photos/1200/800?random=303',
            'https://picsum.photos/1200/800?random=304',
            'https://picsum.photos/1200/800?random=305',
            'https://picsum.photos/1200/800?random=306'
        ])">
            <img src="https://picsum.photos/400/300?random=3" alt="Portraits">
            <div class="gallery-overlay">
                <span class="name">Portraits</span>
                <span class="items">6 photos</span>
            </div>
        </div>

        <!-- Gallery 4 -->
        <div class="gallery-card" onclick="openSwiperGallery('Travel', [
            'https://picsum.photos/1200/800?random=401',
            'https://picsum.photos/1200/800?random=402',
            'https://picsum.photos/1200/800?random=403'
        ])">
            <img src="https://picsum.photos/400/300?random=4" alt="Travel">
            <div class="gallery-overlay">
                <span class="name">Travel</span>
                <span class="items">3 photos</span>
            </div>
        </div>

        <!-- Gallery 5 -->
        <div class="gallery-card" onclick="openSwiperGallery('Food', [
            'https://picsum.photos/1200/800?random=501',
            'https://picsum.photos/1200/800?random=502',
            'https://picsum.photos/1200/800?random=503',
            'https://picsum.photos/1200/800?random=504'
        ])">
            <img src="https://picsum.photos/400/300?random=5" alt="Food">
            <div class="gallery-overlay">
                <span class="name">Food</span>
                <span class="items">4 photos</span>
            </div>
        </div>
    </div>

    <button class="nav-arrow next">
        <i class="fas fa-chevron-right"></i>
    </button>

    <div class="text-center mt-4">


        <a class="add-gallery-btn" href="<?php echo e(route('gallery.upload')); ?>"><i class="fas fa-plus me-2"></i> Create New Gallery</a>
    </div>
</div>

<!-- Swiper Gallery Modal -->
<div class="swiper-gallery-modal" id="swiperGalleryModal">
    <div class="swiper-gallery-container">
        <div class="swiper-gallery-header">
            <div class="swiper-gallery-title" id="swiperGalleryTitle"></div>
            <button class="swiper-gallery-close" onclick="closeSwiperGallery()">&times;</button>
        </div>
        <div class="swiper-gallery-main">
            <div class="swiper swiper-gallery">
                <div class="swiper-wrapper" id="swiperGalleryWrapper"></div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
        <div class="swiper swiper-gallery-thumbs">
            <div class="swiper-wrapper" id="swiperThumbsWrapper"></div>
        </div>
    </div>
</div>


 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/codeliner/laravel/galleryimages/resources/views/index.blade.php ENDPATH**/ ?>